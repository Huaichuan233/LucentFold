# LucentFold — release minify is off; keep empty for Android Studio templates.
