package com.lucent.fold

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import kotlin.math.abs
import kotlin.math.min

data class FoldParams(
    val eyeWidths: Float = 4.92f,
    val blurSpread: Float = 0.12f,
    val darkening: Float = 0.015f,
    val fullFoldRad: Float = (Math.PI / 4.0).toFloat(),
)

class FoldViewModel(application: Application) : AndroidViewModel(application) {

    var angleRad by mutableFloatStateOf(0f)
        private set
    var manualMode by mutableStateOf(true)
    var manualDegrees by mutableFloatStateOf(0f)
    var sensorActive by mutableStateOf(false)
        private set
    var params by mutableStateOf(FoldParams())

    private val sensor = SensorController(application) { tilt ->
        if (!manualMode) angleRad = tilt
    }

    val sensorAvailable: Boolean = sensor.isAvailable

    val displayAngle: Float
        get() = if (manualMode) Math.toRadians(manualDegrees.toDouble()).toFloat() else angleRad

    val foldProgress: Float
        get() = min(1f, abs(displayAngle) / params.fullFoldRad)

    fun startSensors() {
        if (!sensorAvailable) {
            manualMode = true
            return
        }
        sensor.start()
        sensorActive = true
        if (manualMode) {
            // emulator / first launch stays manual until the user opts in
        }
    }

    fun stopSensors() {
        sensor.stop()
        sensorActive = false
    }

    fun useSensors() {
        if (!sensorAvailable) {
            manualMode = true
            return
        }
        sensor.recalibrate()
        manualMode = false
        if (!sensorActive) {
            sensor.start()
            sensorActive = true
        }
    }

    fun useManual() {
        manualMode = true
        manualDegrees = Math.toDegrees(angleRad.toDouble()).toFloat()
    }

    fun setManualDegrees(degrees: Float) {
        manualMode = true
        manualDegrees = degrees.coerceIn(-60f, 60f)
    }

    fun recalibrate() {
        sensor.recalibrate()
        angleRad = 0f
        if (manualMode) manualDegrees = 0f
    }

    override fun onCleared() {
        sensor.stop()
        super.onCleared()
    }
}
