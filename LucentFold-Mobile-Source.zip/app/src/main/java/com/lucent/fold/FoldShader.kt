package com.lucent.fold

/**
 * AGSL port of the frosted-glass fold.
 *
 * The UI lives on a fixed plane (the screen at zero tilt). The eye stays on that
 * plane's normal. The glass rotates around the farther vertical edge. Each pixel
 * ray-marches from the eye through the glass onto the UI plane, then disk-blurs
 * with a radius proportional to the glass-to-plane gap. Misses go black.
 *
 * Android 13+ (API 33) RuntimeShader. Keep the tap count constant — AGSL requires
 * statically bounded loops.
 */
object FoldShader {
    const val AGSL = """
uniform shader content;
uniform float2 size;
uniform float angle;
uniform float eyeDistance;
uniform float blurSpread;
uniform float darkening;

const float kGolden = 2.39996322972865332;
const float kTwoPi  = 6.28318530717958648;

float hash21(float2 p) {
    return fract(sin(dot(p, float2(12.9898, 78.233))) * 43758.5453);
}

half4 sampleUi(float2 px) {
    if (px.x < 0.0 || px.y < 0.0 || px.x > size.x || px.y > size.y) {
        return half4(0.0, 0.0, 0.0, 1.0);
    }
    half4 c = content.eval(px);
    return half4(c.rgb, 1.0);
}

half4 main(float2 p) {
    float tilt = abs(angle);
    if (tilt < 0.00008) {
        return sampleUi(p);
    }

    float hingeRight = step(0.0, angle);
    float hingeX = mix(0.0, size.x, hingeRight);
    float side = mix(1.0, -1.0, hingeRight);
    float d = abs(p.x - hingeX);

    float3 glass = float3(hingeX + side * d * cos(tilt), p.y, d * sin(tilt));
    float3 eye = float3(size * 0.5, eyeDistance);

    float depth = eye.z - glass.z;
    if (depth <= 0.001) {
        return half4(0.0, 0.0, 0.0, 1.0);
    }

    float tHit = eye.z / depth;
    float2 hit = eye.xy + (glass.xy - eye.xy) * tHit;
    float radius = blurSpread * glass.z;

    if (hit.x < -radius || hit.y < -radius ||
        hit.x > size.x + radius || hit.y > size.y + radius) {
        return half4(0.0, 0.0, 0.0, 1.0);
    }

    float attenuation = max(1.0 - darkening * radius, 0.0);
    half3 color;
    if (radius < 0.5) {
        color = sampleUi(hit).rgb * half(attenuation);
    } else {
        float rotation = hash21(p) * kTwoPi;
        half3 sum = half3(0.0);
        for (int i = 0; i < 16; ++i) {
            float fi = float(i);
            float r = radius * sqrt((fi + 0.5) / 16.0);
            float a = fi * kGolden + rotation;
            float2 offset = r * float2(cos(a), sin(a));
            sum += sampleUi(hit + offset).rgb;
        }
        color = (sum / 16.0) * half(attenuation);
    }

    float3 N = normalize(float3(side * sin(tilt), 0.0, cos(tilt)));
    float3 V = normalize(eye - glass);
    float ndv = max(dot(N, V), 0.0);
    float fresnel = pow(1.0 - ndv, 5.0);
    float3 L = normalize(float3(-0.32, 0.22, 0.72));
    float3 H = normalize(L + V);
    float spec = pow(max(dot(N, H), 0.0), 56.0);

    color += half3(0.90, 0.92, 0.96) * half(fresnel * 0.18);
    color += half3(1.0) * half(spec * (0.12 + 0.22 * tilt));

    float hingeGlow = (1.0 - smoothstep(0.0, 6.0, d)) * min(tilt * 1.8, 1.0);
    color += half3(0.95, 0.96, 0.98) * half(hingeGlow * 0.16);
    float contact = (1.0 - d / max(size.x, 1.0)) * min(tilt / 0.7, 1.0);
    color *= half(1.0 - contact * 0.12);

    return half4(color, 1.0);
}
"""
}
