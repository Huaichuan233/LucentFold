package com.lucent.fold.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Bg = Color(0xFF070708)
private val Fg = Color(0xFFF3F1EC)
private val Accent = Color(0xFFC5C0B6)
private val Surface = Color(0xFF121214)

private val Scheme = darkColorScheme(
    primary = Accent,
    onPrimary = Bg,
    background = Bg,
    onBackground = Fg,
    surface = Surface,
    onSurface = Fg,
    secondary = Accent,
    onSecondary = Bg,
)

@Composable
fun LucentTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
