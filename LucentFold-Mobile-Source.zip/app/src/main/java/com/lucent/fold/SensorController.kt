package com.lucent.fold

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.atan2
import kotlin.math.hypot

/**
 * Maps device attitude onto a signed tilt around the screen-space Y axis.
 *
 * Primary: TYPE_ROTATION_VECTOR (already fused). First valid sample is the
 * zero-tilt pose. Gyro on screen-Y predicts ~40 ms ahead to hide sensor latency.
 * Fallback: TYPE_GRAVITY roll, for devices without a rotation vector.
 *
 * No allocations in onSensorChanged.
 */
class SensorController(
    context: Context,
    private val onTilt: (Float) -> Unit,
) : SensorEventListener {

    private val manager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val rotation = manager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        ?: manager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
    private val gyro = manager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    private val gravity = manager.getDefaultSensor(Sensor.TYPE_GRAVITY)
        ?: manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    val isAvailable: Boolean get() = rotation != null || gravity != null

    private val current = FloatArray(9)
    private val reference = FloatArray(9)
    private val relative = FloatArray(9)
    private val scratch = FloatArray(9)
    private var hasReference = false
    private var smoothed = 0f
    private var gyroY = 0f

    fun start() {
        rotation?.let { manager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        gyro?.let { manager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        if (rotation == null) {
            gravity?.let { manager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        }
    }

    fun stop() {
        manager.unregisterListener(this)
    }

    fun recalibrate() {
        hasReference = false
        smoothed = 0f
        onTilt(0f)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_GYROSCOPE -> {
                gyroY = event.values[1]
            }
            Sensor.TYPE_ROTATION_VECTOR, Sensor.TYPE_GAME_ROTATION_VECTOR -> {
                SensorManager.getRotationMatrixFromVector(current, event.values)
                processMatrix()
            }
            Sensor.TYPE_GRAVITY, Sensor.TYPE_ACCELEROMETER -> {
                if (rotation != null) return
                val gx = event.values[0]
                val gy = event.values[1]
                val gz = event.values[2]
                val measured = atan2(gx, hypot(gy, gz))
                if (!hasReference) {
                    reference[0] = measured
                    hasReference = true
                    return
                }
                publish(measured - reference[0])
            }
        }
    }

    private fun processMatrix() {
        if (!hasReference) {
            System.arraycopy(current, 0, reference, 0, 9)
            hasReference = true
            return
        }
        // relative = reference^T * current  (current device axes in the calibrated frame)
        transposeMultiply(reference, current, relative)
        val nx = relative[2]
        val nz = relative[8]
        val measured = atan2(nx, nz)
        publish(measured)
    }

    private fun publish(measured: Float) {
        val predicted = measured + gyroY * PREDICT_S
        smoothed += (predicted - smoothed) * SMOOTH
        val clamped = smoothed.coerceIn(-MAX_TILT, MAX_TILT)
        onTilt(clamped)
    }

    /** out = a^T * b for 3×3 row-major matrices, no alloc. */
    private fun transposeMultiply(a: FloatArray, b: FloatArray, out: FloatArray) {
        scratch[0] = a[0] * b[0] + a[3] * b[3] + a[6] * b[6]
        scratch[1] = a[0] * b[1] + a[3] * b[4] + a[6] * b[7]
        scratch[2] = a[0] * b[2] + a[3] * b[5] + a[6] * b[8]
        scratch[3] = a[1] * b[0] + a[4] * b[3] + a[7] * b[6]
        scratch[4] = a[1] * b[1] + a[4] * b[4] + a[7] * b[7]
        scratch[5] = a[1] * b[2] + a[4] * b[5] + a[7] * b[8]
        scratch[6] = a[2] * b[0] + a[5] * b[3] + a[8] * b[6]
        scratch[7] = a[2] * b[1] + a[5] * b[4] + a[8] * b[7]
        scratch[8] = a[2] * b[2] + a[5] * b[5] + a[8] * b[8]
        System.arraycopy(scratch, 0, out, 0, 9)
    }

    companion object {
        const val PREDICT_S = 0.04f
        const val SMOOTH = 0.62f
        const val MAX_TILT = (Math.PI / 3.0).toFloat()
    }
}
