package com.lucent.fold

import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs

private val Panel = Color(0xE6121214)
private val Fg = Color(0xFFF3F1EC)
private val Muted = Color(0xFF8C8984)
private val Accent = Color(0xFFD9D4C8)

@Composable
fun PreviewScreen(vm: FoldViewModel) {
    val angle = vm.displayAngle
    val shader = remember {
        if (Build.VERSION.SDK_INT >= 33) RuntimeShader(FoldShader.AGSL) else null
    }
    var layerSize by remember { mutableStateOf(IntSize.Zero) }

    Box(Modifier.fillMaxSize().background(Color(0xFF070708))) {
        Box(
            Modifier
                .fillMaxSize()
                .onSizeChanged { layerSize = it }
                .then(
                    if (Build.VERSION.SDK_INT >= 33 && shader != null) {
                        Modifier.foldRuntimeShader(shader, angle, vm.params, layerSize)
                    } else {
                        Modifier.foldFallback(angle)
                    },
                ),
        ) {
            LockFace()
        }

        ControlPanel(
            vm = vm,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(12.dp),
        )
    }
}

@RequiresApi(33)
private fun Modifier.foldRuntimeShader(
    shader: RuntimeShader,
    angle: Float,
    params: FoldParams,
    size: IntSize,
): Modifier = graphicsLayer {
    if (size.width > 0 && size.height > 0) {
        shader.setFloatUniform("size", size.width.toFloat(), size.height.toFloat())
        shader.setFloatUniform("eyeDistance", size.width * params.eyeWidths)
        shader.setFloatUniform("angle", angle)
        shader.setFloatUniform("blurSpread", params.blurSpread)
        shader.setFloatUniform("darkening", params.darkening)
        renderEffect = RenderEffect
            .createRuntimeShaderEffect(shader, "content")
            .asComposeRenderEffect()
        clip = true
        compositingStrategy = androidx.compose.ui.graphics.CompositingStrategy.Offscreen
    }
}

private fun Modifier.foldFallback(angle: Float): Modifier = graphicsLayer {
    val tilt = abs(angle)
    rotationY = Math.toDegrees(angle.toDouble()).toFloat()
    cameraDistance = 18f * density
    val blur = (tilt * 48f).coerceAtMost(64f)
    if (blur > 0.8f && Build.VERSION.SDK_INT >= 31) {
        renderEffect = RenderEffect
            .createBlurEffect(blur, blur, Shader.TileMode.CLAMP)
            .asComposeRenderEffect()
    }
    alpha = (1f - tilt * 0.45f).coerceAtLeast(0.25f)
    clip = true
}

@Composable
private fun LockFace() {
    val now = remember { LocalDateTime.now() }
    val time = now.format(DateTimeFormatter.ofPattern("HH:mm"))
    val date = now.format(DateTimeFormatter.ofPattern("M月d日 EEEE", Locale.CHINA))

    Box(Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(R.drawable.wallpaper),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
        )
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(28.dp))
            Text(
                "LUCENT",
                color = Fg.copy(alpha = 0.7f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 4.sp,
            )
            Spacer(Modifier.height(18.dp))
            Text(
                time,
                color = Fg,
                fontSize = 84.sp,
                fontWeight = FontWeight.Light,
                letterSpacing = (-2).sp,
            )
            Text(date, color = Fg.copy(alpha = 0.82f), fontSize = 16.sp)
            Spacer(Modifier.height(48.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                GlassCard(Modifier.weight(1f).height(118.dp)) {
                    Text("沙丘", color = Fg.copy(alpha = 0.62f), fontSize = 12.sp)
                    Text("24°", color = Fg, fontSize = 36.sp, fontWeight = FontWeight.Light)
                    Text("西风  能见度很好", color = Fg.copy(alpha = 0.7f), fontSize = 11.sp)
                }
                Image(
                    painter = painterResource(R.drawable.still_life),
                    contentDescription = null,
                    modifier = Modifier
                        .weight(1f)
                        .height(118.dp)
                        .clip(RoundedCornerShape(22.dp)),
                    contentScale = ContentScale.Crop,
                )
            }
            Spacer(Modifier.height(10.dp))
            GlassCard(Modifier.fillMaxWidth().height(72.dp)) {
                Text("界面停在零倾角平面", color = Fg.copy(alpha = 0.55f), fontSize = 11.sp)
                Text("屏幕是一块迎向眼睛的霜玻璃。", color = Fg, fontSize = 15.sp)
            }
            Spacer(Modifier.weight(1f))
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 120.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                Box(
                    Modifier
                        .size(58.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.16f)),
                )
                Box(
                    Modifier
                        .size(58.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.16f)),
                )
            }
        }
    }
}

@Composable
private fun GlassCard(modifier: Modifier, content: @Composable () -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(22.dp))
            .background(Color.White.copy(alpha = 0.16f))
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        content()
    }
}

@Composable
private fun ControlPanel(vm: FoldViewModel, modifier: Modifier = Modifier) {
    val degrees = if (vm.manualMode) vm.manualDegrees
    else Math.toDegrees(vm.displayAngle.toDouble()).toFloat()
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Panel)
            .padding(16.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
            Column {
                Text("TILT", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                Text(
                    String.format(Locale.US, "%.1f°", degrees),
                    color = Fg,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Light,
                )
            }
            Spacer(Modifier.weight(1f))
            Text(
                "fold ${(vm.foldProgress * 100).toInt()}%",
                color = Muted,
                fontSize = 11.sp,
            )
        }
        Slider(
            value = degrees,
            onValueChange = { vm.setManualDegrees(it) },
            valueRange = -60f..60f,
            colors = SliderDefaults.colors(
                thumbColor = Accent,
                activeTrackColor = Accent,
                inactiveTrackColor = Fg.copy(alpha = 0.12f),
            ),
        )
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            TextButton(onClick = { vm.useManual() }, modifier = Modifier.weight(1f)) {
                Text("手动", color = if (vm.manualMode) Accent else Fg, fontSize = 13.sp)
            }
            TextButton(
                onClick = { vm.useSensors() },
                modifier = Modifier.weight(1f),
                enabled = vm.sensorAvailable,
            ) {
                Text(
                    "体感",
                    color = if (!vm.manualMode) Accent else Fg,
                    fontSize = 13.sp,
                )
            }
            TextButton(onClick = { vm.recalibrate() }, modifier = Modifier.weight(1f)) {
                Text("校准", color = Fg, fontSize = 13.sp)
            }
        }
        if (!vm.sensorAvailable) {
            Text(
                "传感器不可用（模拟器请用滑块）",
                color = Muted,
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 8.dp),
            )
        }
    }
}
